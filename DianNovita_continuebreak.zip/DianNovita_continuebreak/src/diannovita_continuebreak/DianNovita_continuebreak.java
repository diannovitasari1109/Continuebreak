/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diannovita_continuebreak;

import java.util.Scanner;

/**
 *
 * @author DNS
 */

public class DianNovita_continuebreak {
    
    /**
     * @param args the command line arguments
     */
    
    static void tOne(){
        
        //Statement 1
        for (int i =0; i<10;i++){
            if(i==4){
             break;
            }
            System.out.println(i);
    }

        
    }
    
    static void tTwo (){
        
        //Statement 2
        
        for (int i =0; i<10;i++){
        
            if(i==4){
             continue;
            }
            System.out.println(i);
    }
        
    }
    
    static void  tThree(){
        
        // Statement 3
        int i =0;
        while (i<10){
            System.out.println(i);
            i++;
            
                if(i==4){
                    break;
                }
        }
        
        }
    
    static void tFour(){
        
        // Statement 4
        int i =0;
        while (i<10){
            
                if(i==4){
                    i++;
                    continue;
                }
                System.out.println(i);
                i++;
        }
            
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Anda ingin gunakan Continue Break tipe mana?");
        System.out.println("1. Tipe 1\n"+"2. Tipe 2\n"+"3. Tipe 3\n"+"4. Tipe 4\n");
        System.out.println("Masukan angkanya saja!");
        
        Scanner masuk = new Scanner(System.in);
        int masukan;
        
        masukan = masuk.nextInt();
        
        if (masukan == 1){
            tOne();
        }else if (masukan == 2){
            tTwo();
        }else if (masukan == 3){
            tThree();
        }else if (masukan == 4){
            tFour();
        }else{
            System.out.println("Format yang anda masukan salah! Masukan angkanya 1 atau 2 atau 3 atau 4");
        }
       
         
        
    }
    
}
